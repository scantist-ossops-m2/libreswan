#include <stdbool.h>

struct starter_end;

int resolve_defaultroute_one(struct starter_end *host,
			     struct starter_end *peer, bool verbose);
