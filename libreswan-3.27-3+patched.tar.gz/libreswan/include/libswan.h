/* replacement for libreswan.h */

#include "libreswan.h"

extern int iprange_bits(ip_address low, ip_address high);

